MYSHOP PRO — RAZORPAY PREPAID E-COMMERCE STARTER

Features
- Customer storefront
- Cart
- Prepaid-only Razorpay checkout (COD is not offered)
- Server-side Razorpay order creation
- Payment signature verification
- Razorpay webhook verification
- SQLite product/order database
- Admin login
- Add products, stock, image, description
- Hide products
- Order list + status management

SETUP
1. Install Node.js 20+.
2. Extract this folder.
3. Run: npm install
4. Copy .env.example to .env
5. Put your Razorpay TEST key ID and TEST secret in .env.
6. Set a strong SESSION_SECRET and ADMIN_PASSWORD.
7. Run: npm start
8. Open http://localhost:3000
9. Admin: http://localhost:3000/admin.html

RAZORPAY
- Create Razorpay orders on the server; never expose the API secret to the browser.
- Test first with Razorpay test credentials.
- Configure the webhook endpoint at:
  https://YOUR-DOMAIN/api/razorpay/webhook
- Put the same webhook secret in RAZORPAY_WEBHOOK_SECRET.
- For production, use HTTPS and production keys.
- The server verifies the checkout signature before marking the order paid.

IMPORTANT PRODUCTION NOTES
- This is a starter, not a fully audited production commerce platform.
- Add rate limiting, CSRF protection where appropriate, stronger admin authentication/2FA, email/SMS notifications, shipping integration, refund workflow, backups, logging, and privacy/terms pages before launch.
- Do not store card/UPI credentials yourself.
