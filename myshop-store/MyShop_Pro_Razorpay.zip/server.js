require("dotenv").config();
const express=require("express");
const session=require("express-session");
const crypto=require("crypto");
const Database=require("better-sqlite3");
const Razorpay=require("razorpay");
const path=require("path");

const app=express();
const db=new Database("store.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, description TEXT DEFAULT '', price INTEGER NOT NULL,
 image TEXT DEFAULT '', stock INTEGER DEFAULT 0, active INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT DEFAULT '',
 address TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT DEFAULT 'created',
 razorpay_order_id TEXT, razorpay_payment_id TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
 product_id INTEGER, name TEXT NOT NULL, price INTEGER NOT NULL, qty INTEGER NOT NULL
);
`);

const count=db.prepare("SELECT COUNT(*) c FROM products").get().c;
if(!count){
 const add=db.prepare("INSERT INTO products(name,description,price,image,stock) VALUES(?,?,?,?,?)");
 add.run("Premium T-Shirt","Comfortable everyday T-shirt",599,"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=900",20);
 add.run("Sneakers","Casual sneakers",1299,"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900",15);
 add.run("Smart Watch","Modern smartwatch",1999,"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900",10);
}

const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
 ? new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET}) : null;

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:process.env.SESSION_SECRET||"dev-secret-change-me",
 resave:false,saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public")));

function admin(req,res,next){
 if(req.session.admin) return next();
 res.status(401).json({error:"Admin login required"});
}
function validAmount(n){return Number.isInteger(n)&&n>0}
function verifySignature(orderId,paymentId,signature){
 const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET)
   .update(orderId+"|"+paymentId).digest("hex");
 return crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature||""));
}

app.get("/api/config",(req,res)=>res.json({keyId:process.env.RAZORPAY_KEY_ID||"",storeName:process.env.STORE_NAME||"MyShop"}));
app.get("/api/products",(req,res)=>res.json(db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all()));

app.post("/api/orders/create",async(req,res)=>{
 try{
  if(!razorpay) return res.status(500).json({error:"Razorpay is not configured on the server"});
  const {name,phone,email="",address,items}=req.body;
  if(!name||!phone||!address||!Array.isArray(items)||!items.length) return res.status(400).json({error:"Missing checkout details"});
  const get=db.prepare("SELECT * FROM products WHERE id=? AND active=1");
  let total=0, normalized=[];
  for(const item of items){
   const p=get.get(Number(item.id)); const qty=Number(item.qty);
   if(!p||!Number.isInteger(qty)||qty<1||qty>p.stock) return res.status(400).json({error:"Product unavailable or insufficient stock"});
   total += p.price*qty;
   normalized.push({p,qty});
  }
  const local=db.prepare("INSERT INTO orders(customer_name,phone,email,address,amount,status) VALUES(?,?,?,?,?,?)")
    .run(name,phone,email,address,total,"created");
  const orderId=local.lastInsertRowid;
  const ins=db.prepare("INSERT INTO order_items(order_id,product_id,name,price,qty) VALUES(?,?,?,?,?)");
  const tx=db.transaction(()=>normalized.forEach(x=>ins.run(orderId,x.p.id,x.p.name,x.p.price,x.qty)));
  tx();
  const rp=await razorpay.orders.create({amount:total,currency:"INR",receipt:"order_"+orderId,payment_capture:1});
  db.prepare("UPDATE orders SET razorpay_order_id=? WHERE id=?").run(rp.id,orderId);
  res.json({orderId,razorpayOrderId:rp.id,amount:total,keyId:process.env.RAZORPAY_KEY_ID});
 }catch(e){console.error(e);res.status(500).json({error:"Could not create order"});}
});

app.post("/api/payments/verify",(req,res)=>{
 try{
  const {orderId,razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
  const o=db.prepare("SELECT * FROM orders WHERE id=?").get(orderId);
  if(!o||o.razorpay_order_id!==razorpay_order_id) return res.status(400).json({error:"Invalid order"});
  if(!verifySignature(razorpay_order_id,razorpay_payment_id,razorpay_signature)) return res.status(400).json({error:"Payment verification failed"});
  const tx=db.transaction(()=>{
   db.prepare("UPDATE orders SET status='paid',razorpay_payment_id=? WHERE id=?").run(razorpay_payment_id,orderId);
   const rows=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(orderId);
   const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?");
   for(const r of rows) dec.run(r.qty,r.product_id,r.qty);
  });
  tx();
  res.json({ok:true});
 }catch(e){console.error(e);res.status(500).json({error:"Verification failed"});}
});

app.post("/api/razorpay/webhook",express.raw({type:"application/json"}),(req,res)=>{
 try{
  if(!process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(200).send("ok");
  const sig=req.headers["x-razorpay-signature"];
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_WEBHOOK_SECRET).update(req.body).digest("hex");
  if(!sig||sig!==expected) return res.status(400).send("invalid signature");
  const event=JSON.parse(req.body.toString());
  if(event.event==="payment.captured"){
   const p=event.payload.payment.entity;
   db.prepare("UPDATE orders SET status='paid',razorpay_payment_id=? WHERE razorpay_order_id=?").run(p.id,p.order_id);
  }
  res.status(200).send("ok");
 }catch(e){console.error(e);res.status(500).send("error");}
});

app.post("/api/admin/login",(req,res)=>{
 const {username,password}=req.body;
 if(username===process.env.ADMIN_USERNAME&&password===process.env.ADMIN_PASSWORD){req.session.admin=true;return res.json({ok:true});}
 res.status(401).json({error:"Invalid credentials"});
});
app.post("/api/admin/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/admin/me",(req,res)=>res.json({loggedIn:!!req.session.admin}));

app.get("/api/admin/products",admin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products",admin,(req,res)=>{
 const {name,description="",price,image="",stock=0}=req.body;
 if(!name||!validAmount(Number(price))||!Number.isInteger(Number(stock))||Number(stock)<0) return res.status(400).json({error:"Invalid product"});
 const r=db.prepare("INSERT INTO products(name,description,price,image,stock) VALUES(?,?,?,?,?)").run(name,description,Number(price),image,Number(stock));
 res.json({id:r.lastInsertRowid});
});
app.put("/api/admin/products/:id",admin,(req,res)=>{
 const {name,description="",price,image="",stock=0,active=1}=req.body;
 if(!name||!validAmount(Number(price))) return res.status(400).json({error:"Invalid product"});
 db.prepare("UPDATE products SET name=?,description=?,price=?,image=?,stock=?,active=? WHERE id=?")
  .run(name,description,Number(price),image,Number(stock),active?1:0,Number(req.params.id));
 res.json({ok:true});
});
app.delete("/api/admin/products/:id",admin,(req,res)=>{
 db.prepare("UPDATE products SET active=0 WHERE id=?").run(Number(req.params.id));res.json({ok:true});
});
app.get("/api/admin/orders",admin,(req,res)=>{
 const orders=db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
 for(const o of orders)o.items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(o.id);
 res.json(orders);
});
app.patch("/api/admin/orders/:id",admin,(req,res)=>{
 const allowed=["paid","processing","shipped","delivered","cancelled","refunded"];
 if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
 db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,Number(req.params.id));
 res.json({ok:true});
});

app.listen(process.env.PORT||3000,()=>console.log("MyShop running on http://localhost:"+(process.env.PORT||3000)));
